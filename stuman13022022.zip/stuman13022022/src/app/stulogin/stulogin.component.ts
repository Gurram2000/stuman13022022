import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-stulogin',
  templateUrl: './stulogin.component.html',
  styleUrls: ['./stulogin.component.css']
})
export class StuloginComponent implements OnInit {
  
  stuloginform: FormGroup | any;
  submitted = false;
  stuloginactive : boolean=false;

  constructor( private http :HttpClient, private route: Router,private formBuilder: FormBuilder,private appcomp: AppComponent) { }

ngOnInit(): void {
  

  this.stuloginform = this.formBuilder.group({
    
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(9)]],

    
    
});
}
get f() { return this.stuloginform.controls; }

btnClick=  () => {
  this.submitted=true;
  if(this.stuloginform.invalid){
    return;
  }

  this.http.get<any>("http://localhost:8000/students").subscribe(res=>{
    const user =res.find((a:any)=>{

      return a.email===this.stuloginform.value.email && a.password===this.stuloginform.value.password 
      
      
    });

    if(user){
      
      this.route.navigateByUrl('/quizwelcome');
      this.appcomp.stulogin();
            
    }else{
      alert("user not found");
    }
  })

  

  
};


}
