import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ServiceService } from '../service.service';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  section: any=['A','B','C'];
  submitted = false;
  editStudent: FormGroup|any;


  constructor( private student: ServiceService, private router: ActivatedRoute ) { }

  
  
  message: boolean=false;

  ngOnInit(): void {
    //console.log( this.router.snapshot.params.id );
    this.student.getStudentById( this.router.snapshot.params['id'] ).subscribe( ( result: any ) => {
      //console.log( result );
      this.editStudent=new FormGroup( {
        name: new FormControl( result['name'],[Validators.required]),
        email: new FormControl( result['email'],[Validators.required] ),
        password: new FormControl( result['password'],[Validators.required] ),
        dept: new FormControl( result['dept'],[Validators.required] ),
        sec: new FormControl( result['sec'],[Validators.required] ),

      } );
    } );
  }
  get f() {return this.editStudent.controls}
  

  UpdateData() {
    this.submitted=true;

    if(this.editStudent.invalid){
      return;
    }

    this.student.updateStudentData( this.router.snapshot.params['id'], this.editStudent.value ).subscribe( ( result) => {
      //console.log( result );
      this.message=true;
      this.message=true;
      
    } )
    

    Swal.fire({  
      position: 'top',  
      icon: 'success',  
      title: 'DATA IS SUCESSFULLY UPDATED',  
      
      
    })  
  }
  removeMessage() {
    this.message=false;
  }

}
