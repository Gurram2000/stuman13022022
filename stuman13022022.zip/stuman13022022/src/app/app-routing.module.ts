import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DataComponent } from './data/data.component';
import { EditComponent } from './edit/edit.component';
import { FormComponent } from './form/form.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { QuestionComponent } from './question/question.component';
import { QuizwelcomeComponent } from './quizwelcome/quizwelcome.component';
import { StuloginComponent } from './stulogin/stulogin.component';
const routes: Routes = [
  { path: 'form',
    component: FormComponent
  },
  {
    path:'',
    component: LoginComponent,
    pathMatch:'full'
  },
  { path: 'data',
    component: DataComponent
  },
  {
    path: 'edit/:id',
    component: EditComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'stulogin',
    component: StuloginComponent
  },
  {
    path: 'quizwelcome',
    component: QuizwelcomeComponent
  },
  {
    path: 'question',
    component: QuestionComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
