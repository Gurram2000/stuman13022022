import { Component, OnInit } from '@angular/core';
import { interval } from 'rxjs';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {

  public name: string="";
  public quelist : any=[];
  public currque:number = 0;
  public points: number = 0;
  counter=60;
  correctanswer:number = 0;
  incorrectanswer:number = 0;
  interval$:any;
  progress:string="0";
  isQuizCompleted : boolean =false;
  constructor(private service: ServiceService) { }

  ngOnInit(): void {
    this.name=localStorage.getItem("name")!;
    this.getAllQuestions();
    this.startCounter();
  }
  getAllQuestions(){
    this.service.getQuestionJson()
    .subscribe(res=>{
      this.quelist=res.questions;
    })

  }
  nextQuestion(){
    this.currque++;

  }
  prevQuestion(){
    this.currque--;

  }
  answer(currentQno:number,option:any){
    
    if(currentQno===this.quelist.length){
      this.isQuizCompleted =true;
      this.stopcounter;
    }
    if(option.correct){
      this.points+=10;
      this.correctanswer++;
      setTimeout(()=>{
        this.currque++;
        this.resetCounter();
        this.getprogresspercentage();   

      },1000);
      

      
    }
    else{
      setTimeout(()=>{
        this.currque++;
        this.incorrectanswer++;
        this.resetCounter();
        this.getprogresspercentage();
      },1000);

       this.points -=10;
    }

  }
  startCounter(){
      this.interval$ = interval(1000)
      .subscribe(val=>{
        this.counter--;
        if(this.counter===0){
          this.currque++;
          this.counter=60;
          this.points-=10;
        }
      })
      setTimeout(()=>{
          this.interval$.unsubscribe();  
      },600000);
  }
  stopcounter(){
    this.interval$.unsubscribe();
    this.counter=0;

  }
  resetCounter(){
    this.stopcounter();
    this.counter=60;
    this.startCounter();

  }
  resetquiz(){
    this.resetCounter();
    this.getAllQuestions();
    this.points=0;
    this.counter=60;
    this.currque=0;
    this.progress="0";

  }
  getprogresspercentage(){
    this.progress=((this.currque/this.quelist.length)*100).toString();
    return this.progress;
  }



}
